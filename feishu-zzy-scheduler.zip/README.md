# feishu-zzy-scheduler

This repository separates GitHub Actions schedule verification from the Feishu automation script.

## Workflows

- `.github/workflows/schedule_probe.yml`
  - Runs every 5 minutes.
  - Only prints trigger context and uploads a small artifact.
  - Use this first to confirm GitHub scheduled workflows are registering correctly.

- `.github/workflows/auto_copy.yml`
  - Runs the Feishu script at Beijing time 09:24-00:24 every hour.
  - GitHub cron is evaluated in UTC, so the cron is `24 1-16 * * *`.
  - Also supports manual `workflow_dispatch` for controlled testing.

## Required Secrets

Add these under `Settings -> Secrets and variables -> Actions -> Repository secrets`:

- `APP_ID`
- `APP_SECRET`
- `FEISHU_WEBHOOK`

GitHub does not allow reading secret values from another repository, so they must be added to this repository again.

## Verification Order

1. Create the repository and push or upload these files.
2. Wait 5-15 minutes for `Schedule Probe` to run from the `schedule` event.
3. After the probe appears, add the three secrets.
4. Run `Auto Copy Feishu Drama` manually once.
5. Keep `auto_copy.yml` scheduled for the real automation.
